/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author roberta.bsilva17
 */
public class saopoio {
            private int id;
private String materia;
private String site;
private String tarefasemana;

public int getId() {
    return id;
}

public void setId(int id) {
    this.id = id;
}

public String getMateria() {
    return materia;
}

public void setMateria(String materia) {
    this.materia = materia;
}

public String getSite() {
    return site;
}

public void setSite(String site) {
    this.site = site;
}

public String getTarefasemana() {
    return tarefasemana;
}

public void setTarefasemana(String tarefasemana) {
    this.tarefasemana = tarefasemana;
}
}
