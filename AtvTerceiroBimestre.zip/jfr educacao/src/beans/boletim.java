/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author roberta.bsilva17
 */
public class boletim {
     private int id;
    private String materia;
    private double notamin1;
    private double notamin2;
    private double notanecess;
    
  

public int getId() {
    return id;
}

public void setId(int id) {
    this.id = id;
}

public String getMateria() {
    return materia;
}

public void setMateria(String materia) {
    this.materia = materia;
}

public double getNotamin1() {
    return notamin1;
}

public void setNotamin1(double notamin1) {
    this.notamin1 = notamin1;
}

public double getNotamin2() {
    return notamin2;
}

public void setNotamin2(double notamin2) {
    this.notamin2 = notamin2;
}

public double getNotanecess() {
    return notanecess;
}

public void setNotanecess(double notanecess) {
    this.notanecess = notanecess;
}
}
