/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author roberta.bsilva17
 */
public class cursos {
         private int id;
private String titulo;
private String descricao;
private int cargahoraria;
private String plataforma;


public int getId() {
    return id;
}

public void setId(int id) {
    this.id = id;
}

public String getTitulo() {
    return titulo;
}

public void setTitulo(String titulo) {
    this.titulo = titulo;
}

public String getDescricao() {
    return descricao;
}

public void setDescricao(String descricao) {
    this.descricao = descricao;
}

public int getCargahoraria() {
    return cargahoraria;
}

public void setCargahoraria(int cargahoraria) {
    this.cargahoraria = cargahoraria;
}

public String getPlataforma() {
    return plataforma;
}

public void setPlataforma(String plataforma) {
    this.plataforma = plataforma;
}
}
